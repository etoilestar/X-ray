params = {}

params['lr'] = 1e-3
params['weight_decay'] = 1e-5
params['mixup'] = False